import face_recognition
import cv2
import numpy as np
from PIL import Image
import datetime
#import requests
from io import BytesIO
import urllib.request
import firebase_admin
from firebase_admin import credentials,db
#state mac dinh 0
#1 mở cửa
#2 hết hạn
#3 user không hợp lệ
#setup firebase
cred = credentials.Certificate("./GymApp.json")
firebase=firebase_admin.initialize_app(cred,{"databaseURL":"https://gymapp-e8630-default-rtdb.asia-southeast1.firebasedatabase.app/"})
global known_face_names, known_face_encodings,process_this_frame,id,userid
url='http://192.168.100.200/cam-hi.jpg'
#video_capture = cv2.VideoCapture(0)
# Initialize some variables
curent= datetime.datetime.now()
current_time = curent.strftime("%Y-%m-%d")
def check_day(userid):
    curent= datetime.datetime.now()
    print(userid)
    start = db.reference("/users").child(userid).child('courses').get()
    valid = 0
    #print(start)
    for courses in start:
        #print(courses)
        #data=db.reference("/users").child(userid).child('courses').child(courses).get()
        data=courses
        #data = json.loads(day)
        end = data['end']
        #print(end-current_time)
        expire_day = datetime.datetime.strptime(end, "%Y-%m-%d")
        #print (a-datetime.datetime.now())
        
        start = data['start']
        start_day = datetime.datetime.strptime(start, "%Y-%m-%d")
        if (curent>=start_day and curent<=expire_day):
            print("Vô được")
            valid =1
            #db.reference("/communicate").update({"state":"1"})
            #break
            return valid
    if (valid==0):
        print("Các khóa học đã hết hạn")
        db.reference("/communicate").update({"state":"expi"})
        return valid
def convert_to_userid(id):
    global userid
    userid = db.reference("/rfid").child(id).get()
    #print (userid)
    return userid
def getdata():
    # face_locations = []
    # face_encodings = []
    # face_names = []
    
    
    global known_face_names, known_face_encodings, process_this_frame,id,userid
    id = db.reference("/communicate").child('user').get()
    while (len(id)<8):
        id = db.reference("/communicate").child('user').get()
    
    known_face_names = [
        "User"
    ]
    convert_to_userid(id)
    #id = getdata("8FF7998A")
    image = db.reference("/users").child(userid).child('image').get()
    print(image)
    #url='http://192.168.165.200/cam-hi.jpg'
    #url='https://firebasestorage.googleapis.com/v0/b/gymapp-3f0ec.appspot.com/o/Kiet.jpg?alt=media&token=39a057af-b6e9-4c2e-807f-e9a6a0794f11'
    # Load a sample picture and learn how to recognize it.
    # Load a second sample picture and learn how to recognize it.
    response = urllib.request.urlopen(image)

    kiet_image = face_recognition.load_image_file(response)
    kiet_image = cv2.cvtColor(kiet_image, cv2.COLOR_BGR2RGB)
    kiet_face_encoding = face_recognition.face_encodings(kiet_image)[0]

    # Create arrays of known face encodings and their names
    known_face_encodings = [   
        kiet_face_encoding
    ]
    process_this_frame = True
    return image
#lấy id và hình ảnh để xử lý
#
def main():
    
    global process_this_frame,id,userid
    #id = "8FF7998A"
    image=getdata()
    while check_day(userid)==0:
        print(check_day(userid))
        new_id = db.reference("/communicate").child('user').get()
        print(id)
        if new_id !=id:
            image=getdata()
            print(id)
    #check_face = db.reference("/communicate").child('state').get()
    #while (len(id)<8):
        #image=getdata()
        #check_face = db.reference("/communicate").child('state').get()
    while True:
        # Grab a single frame of video
        #response = requests.get(url)
        #img_resp = Image.open(BytesIO(response.content))
        img_resp=urllib.request.urlopen(url)
        #img_resp=urllib.request.urlopen(url)
        imgnp=np.array(bytearray(img_resp.read()),dtype=np.uint8)
        img=cv2.imdecode(imgnp,-1)
    # img = captureScreen()
        #imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
        #imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)
        
        #ret, frame = video_capture.read()

        # Only process every other frame of video to save time
        if process_this_frame:
            # Resize frame of video to 1/4 size for faster face recognition processing
            #small_frame = cv2.resize(img, (0, 0), fx=0.25, fy=0.25)
            small_frame =cv2.resize(img, (0, 0), None, 0.25, 0.25)
            # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
            #rgb_small_frame = small_frame[:, :, ::-1]
            rgb_small_frame = np.ascontiguousarray(small_frame[:, :, ::-1])
            # Find all the faces and face encodings in the current frame of video
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
            face_names = []
            for face_encoding in face_encodings:
                # See if the face is a match for the known face(s)
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                name = "Unknown"
                # Or instead, use the known face with the smallest distance to the new face
                face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                best_match_index = np.argmin(face_distances)
                if matches[best_match_index]:
                    name = known_face_names[best_match_index]
                    #check_day(id)
                    state = db.reference("/communicate").update({"state":"goin"})
                    hist = db.reference("/users").child(userid).child('hist').child(current_time).set({'selected': True, 'selectedColor': '#00cccc'})
                    #stattus=2
                face_names.append(id)
                if (name == "Unknown"):
                    state = db.reference("/communicate").update({"state":"nval"})
                    #stattus =1
        process_this_frame = not process_this_frame


        # Display the results
        for (top, right, bottom, left), name in zip(face_locations, face_names):
            # Scale back up face locations since the frame we detected in was scaled to 1/4 size
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            # Draw a box around the face
            cv2.rectangle(img, (left, top), (right, bottom), (0, 0, 255), 2)

            # Draw a label with a name below the face
            cv2.rectangle(img, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(img, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

        # Display the resulting image
        cv2.imshow('Video', img)
        #cv2.imshow('test', img)
        # Hit 'q' on the keyboard to quit!
        new_id = db.reference("/communicate").child('user').get()
        if new_id !=id:
            image=getdata()
            while check_day(userid)==0:
                print(check_day(userid))
                new_id = db.reference("/communicate").child('user').get()
                if new_id !=id:
                    image=getdata()
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    
    # Release handle to the webcam
    #video_capture.release()
    cv2.destroyAllWindows()
if __name__ == "__main__":
    main()