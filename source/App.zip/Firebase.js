import { initializeApp } from "firebase/app";
import { initializeAuth, getReactNativePersistence } from "firebase/auth";
import { getDatabase } from 'firebase/database';
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';
const firebaseConfig = {
    apiKey: "AIzaSyAtHo_l-k8ehqn5DM6o8dsOouAsIZmHBno",

    authDomain: "gymapp-e8630.firebaseapp.com",

    databaseURL: "https://gymapp-e8630-default-rtdb.asia-southeast1.firebasedatabase.app",

    projectId: "gymapp-e8630",

    storageBucket: "gymapp-e8630.appspot.com",

    messagingSenderId: "719535665492",

    appId: "1:719535665492:web:bd7c2e8a2eb8ad5ac898c1"

};


// Initialize Firebase
export const FIREBASE_APP = initializeApp(firebaseConfig);
export const FIREBASE_DB = getDatabase(FIREBASE_APP);
export const FIREBASE_AUTH = initializeAuth(FIREBASE_APP, {
    persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});