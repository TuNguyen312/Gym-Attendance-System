export default {
    theme: "#b7e7ec",
    title: "#2f5771",
    button: "#151234",
    text: "#151234"
}