import React, { createContext, useState } from 'react'

const AuthContext = createContext();

const AuthProvider = ({ children }) => {
    const [isAuthenticated, setAuthenticated] = useState(false);
    const [uid, setUid] = useState('');
    return (
        <AuthContext.Provider value={{ isAuthenticated, setAuthenticated, uid, setUid }}>
            {children}
        </AuthContext.Provider >
    )
}

export { AuthContext, AuthProvider }
