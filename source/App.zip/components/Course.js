import { StyleSheet, Text, View, Button, Image, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
const windowHeight = Dimensions.get('window').height;
function Discount({ sale }) {
    if (!sale)
        return (<></>)
    else
        return (
            <View style={styles.discountcontainer}>
                <Text >{sale}%</Text>
            </View>
        );
}
export default function Course({ course }) {
    // sale = 20;
    // // const formatted = new Intl.NumberFormat('vi-VN', {
    // //     style: 'currency', 
    // //     currency: 'VND'
    // // }).format(price)
    const formatPrice = (price) => {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND',
        }).format(price);
    };

    // const NewPrice = Math.round(price * (1 - (sale || 0) / 100));


    const navigation = useNavigation();
    return (
        <TouchableOpacity style={styles.container} onPress={() => navigation.navigate("CourseDetails", { name: course.name, course: course })}>
            <View style={styles.post}>
                {/* {detail &&
                <Discount
                sale={sale}
                />} */}
                <Image style={styles.postimg} source={{ uri: course.img }} />
                <Text style={styles.posttitle}>
                    {course.name}
                </Text>
                <Text style={styles.time}>
                    Thời hạn: {course.time} tháng
                </Text>
                <View style={styles.price}>
                    {/* {sale &&
                        <Text style={styles.Oldprice}>
                            {formatPrice(price)}
                        </Text>
                    } */}
                    <Text style={styles.Newprice}>
                        {formatPrice(course.price)}
                    </Text>
                </View>
            </View>
        </TouchableOpacity>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 3,
    },
    post: {
        width: '100%',
        height: windowHeight * 0.35,
        alignItems: 'center',
        borderColor: '#d6d5d0',
        borderWidth: 1,
        backgroundColor: '#fff',
        borderRadius: 11,
    },
    postimg: {
        height: '60%',
        width: '100%',
        borderRadius: 10,
    },
    posttitle: {
        color: "#2f5771",
        fontWeight: 'bold',
        fontSize: 17,
        height: '10%',
        marginTop: 5,
    },
    time: {

        height: '10%',
        marginHorizontal: 5,
    },
    price: {
        //height:'10%',
        //fontWeight:'bold',
        //textAlign: 'center',
    },
    Oldprice: {
        //fontWeight:'bold',
        textDecorationLine: 'line-through'
    },
    Newprice: {
        fontWeight: 'bold',
    },
    notDetail: {
        display: 'none'
    },
    discountcontainer: {
        zIndex: 2,
        height: 40,
        width: 40,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "#b7e7ec",
        borderRadius: 50,
        position: 'absolute',
        alignSelf: 'flex-start',
        margin: 5
    }
});