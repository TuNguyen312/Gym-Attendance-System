import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';

export default function Sign({ course, }) {
    const navigation = useNavigation();
    const formatted = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(course.price)
    return (
        <View style={styles.signcontent}>
            <TouchableOpacity style={styles.sign} onPress={() => navigation.navigate('CourseDetails', { name: course.name, course: course })}>
                <Image source={{ uri: course.img }} style={styles.signimg} />
                <Text style={styles.signtype}>
                    {course.name}
                </Text>
                <Text style={styles.signprice}>
                    {formatted}
                </Text>
            </TouchableOpacity>
        </View>
    )
}
const styles = StyleSheet.create({
    signcontent: {
        width: '100%',
        paddingHorizontal: 20,
        paddingBottom: 10,
    },
    sign: {
        borderColor: '#d6d5d0',
        borderWidth: 1,
        borderRadius: 11,
    },
    signimg: {
        width: '100%',
        height: '60%',
        borderRadius: 10,
    },
    signtype: {
        textAlign: 'center',
        justifyContent: 'center',
        height: '20%',
        paddingTop: 15,
        fontWeight: 'bold',
        fontSize: 18,
        color: "#151234",
    },
    signprice: {
        height: '10%',
        textAlign: 'center',
        fontSize: 18,
        color: "#151234",
    },
});