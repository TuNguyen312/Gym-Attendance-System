import React from 'react';
import { TouchableOpacity, StyleSheet, Text } from 'react-native';

export default AuthCustomButton = ({ buttonText, handleOnPress }) => {
    return (
        <TouchableOpacity style={styles.buttonContainer} onPress={() => handleOnPress()}>
            <Text style={styles.buttonText}>{buttonText}</Text>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    buttonContainer: {
        backgroundColor: '#2f5771',
        padding: 12,
        marginTop: 25,
        paddingHorizontal: 128,
        borderRadius: 8,
    },
    buttonText: {
        color: '#fff',
        fontSize: 18,
    },
});
