// Nguyen Le Hoang Tu 21521613
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native'
import React from 'react'

export default function CustomNavigateText({ text1, text2, handleOnPress }) {
    return (
        <View style={styles.textContainer}>
            <Text style={styles.text1}>
                {text1}
            </Text>
            <TouchableOpacity onPress={handleOnPress}>
                <Text style={styles.text2}>
                    {text2}
                </Text>
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    textContainer: {
        marginTop: 20,
        flexDirection: 'row',
    },
    text1: {
        fontSize: 16,
        marginRight: 4,
    },
    text2: {
        color: 'blue',
        fontSize: 16,
        fontWeight: 'bold',
    },
})
