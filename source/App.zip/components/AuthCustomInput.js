// Nguyen Le Hoang Tu 21521613
import { View, TextInput, StyleSheet } from 'react-native'
import React from 'react'
import Ionicons from 'react-native-vector-icons/Ionicons'

export default function AuthCustomInput({ iconName, placeHolderText, setValue, secureTextEntry }) {
    return (
        <View style={styles.customInputContainer}>
            <Ionicons style={styles.icon}
                name={iconName}
                size={25}
            />
            <TextInput style={styles.textInput}
                placeholder={placeHolderText}
                onChangeText={(text) => setValue(text)}
                secureTextEntry={secureTextEntry}
            />
        </View>
    );
}
const styles = StyleSheet.create({
    customInputContainer: {
        // backgroundColor: '#ffa',
        alignItems: 'center',
        flexDirection: 'row',
        marginTop: 20,
        marginHorizontal: 50,
        borderWidth: 1,
        borderColor: '#b3b3b3',
        borderRadius: 10,
        backgroundColor: '#f2f2f2',
    },
    icon: {
        paddingLeft: 10,
    },
    textInput: {
        flex: 1,
        paddingHorizontal: 8,
        paddingVertical: 15,
    },
});
