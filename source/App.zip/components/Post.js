import { StyleSheet, Text, View, Button, Image, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
const windowHeight = Dimensions.get('window').height;
export default function Post({ title, date, img, handleOnPress }) {
    return (
        <TouchableOpacity style={{ width: 300, margin: 10 }} onPress={handleOnPress}>
            <View style={styles.post}>
                <Image style={styles.postimg} source={img} />
                <Text style={styles.posttitle}>
                    {title}
                </Text>
                <Text style={styles.date}>
                    {date}
                </Text>
            </View>
        </TouchableOpacity>
    )
}
const styles = StyleSheet.create({
    post: {
        width: 300,
        height: windowHeight * 0.3,
        borderColor: '#d6d5d0',
        borderWidth: 1,
        borderRadius: 11,
    },
    postimg: {
        height: '70%',
        width: '100%',
        borderRadius: 10,
    },
    posttitle: {
        fontWeight: 'bold',
        fontSize: 15,
        height: '20%',
        marginTop: 5,
        marginHorizontal: 5
    },
    date: {
        fontSize: 10,
        height: '10%',
        marginHorizontal: 5,
    }
});