// Nguyen Le Hoang Tu 21521613
import React from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';

export default function Logo({ imageSource, text }) {
    return (
        <View style={styles.logoContainer}>
            <Image source={imageSource} style={styles.logo} />
            <Text style={styles.logoText}>{text}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    logoContainer: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        width: 120,
        height: 120,
        borderRadius: 60,
    },
    logoText: {
        color: '#000',
        paddingTop: 8,
        fontSize: 22,
        fontWeight: 'bold',
    }
});
