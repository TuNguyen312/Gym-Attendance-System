import { StyleSheet, Text, View, FlatList } from 'react-native'
import PLPost from './PLPost'
import { useNavigation, useRoute } from '@react-navigation/native'
import React from 'react'

const PostList = () => {
    const route = useRoute();
    const { posts } = route.params;
    const navigation = useNavigation();
    return (
        <View style={{ flex: 1 }}>
            <FlatList
                style={{ flex: 1 }}
                data={posts}
                keyExtractor={post => post.id}
                renderItem={({ item }) => (
                    < PLPost
                        title={item.title}
                        img={{ uri: item.img }}
                        content={item.content}
                        date={item.date}
                        handleOnPress={() => navigation.navigate("PostDetails", { item: item, name: item.title })}
                    />
                )
                }
            />
        </View>
    )
}

export default PostList

const styles = StyleSheet.create({})