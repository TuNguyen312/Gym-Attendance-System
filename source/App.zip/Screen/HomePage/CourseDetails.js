import { StyleSheet, Text, View, Image, ScrollView, TouchableOpacity, Modal, Alert } from 'react-native'
import { useRoute } from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { AuthContext } from '../../AuthContext';
import { FIREBASE_DB } from '../../Firebase';
import { onValue, ref, set } from "firebase/database";
import React, { useState, useEffect, useContext } from 'react'
import moment from 'moment';
const CourseDetails = () => {
    const route = useRoute();
    const { course } = route.params;
    const { uid } = useContext(AuthContext);
    const [userData, setUserData] = useState({});
    const [isModalVisible, setModalVisible] = useState(false);
    const [totalSpend, setTotalSpend] = useState(0);
    const [bookmarkIcon, setBookmarkIcon] = useState('bookmark-outline');
    const formatted = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(course.price)
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, "/users/" + uid), (snapshot) => {
            const data = snapshot.val();
            setUserData(data);
            if (data.bookmarks) {
                data.bookmarks.forEach(bookmark => {
                    if (bookmark.id === course.id) {
                        setBookmarkIcon('bookmark');
                    }
                })
            }
            setTotalSpend(data.totalSpend);
        })
    }, [FIREBASE_DB])
    const handleOnBuy = () => {
        setModalVisible(false);
        var wasBought = false;
        const today = new Date(moment().format("YYYY-MM-DD"));
        const getEndDate = (today) => {
            var month = Number(today.getMonth()) + Number(1) + course.time;
            var year = Number(today.getFullYear());
            if (month > 12) {
                year = year + Math.floor(month / 12);
                month = month % 12;
                if (month === 0) {
                    month = 12;
                }
            }
            return year + '-' + month + '-' + today.getDate();
        }
        const start = today.getFullYear() + "-" + (Number(today.getMonth()) + Number(1)) + "-" + today.getDate();
        const end = getEndDate(today);
        const currCourse = {
            course_id: course.id,
            name: course.name,
            price: course.price,
            start: start,
            end: end,
        };
        const tempSpend = totalSpend + course.price;
        if (userData.courses) {
            var courses = userData.courses;
            courses.forEach((userCourse) => {
                const start = new Date(userCourse.start);
                const end = new Date(userCourse.end);
                if (((today <= end) && (today >= start)) && (userCourse.course_id === course.id)) {
                    wasBought = true;
                }
            })
            if (!wasBought) {
                courses = [...courses, currCourse];
                set(ref(FIREBASE_DB, "/users/" + uid + '/courses/'), courses);
                set(ref(FIREBASE_DB, "/users/" + uid + '/totalSpend'), tempSpend);
            }
            else {
                Alert.alert("Bạn đã mua khóa học này rồi!")
            }
        }
        else {
            userData.courses = [currCourse];
            userData.totalSpend = tempSpend;
            set(ref(FIREBASE_DB, "/users/" + uid), userData);
        }
    }
    const handleOnBookmark = () => {
        const currBookmark = {
            id: course.id,
            category: course.category,
            name: course.name,
            time: course.time,
            price: course.price,
        }
        if (userData.bookmarks) {
            var bookmarks = userData.bookmarks;
            var updated = [];
            var inBookmarks = false;
            bookmarks.forEach((userBookmark) => {
                if (userBookmark.id === course.id) {
                    inBookmarks = true;
                }
                else {
                    updated = [...updated, userBookmark];
                }
            })
            if (inBookmarks) {
                set(ref(FIREBASE_DB, "/users/" + uid + "/bookmarks/"), updated);
                setBookmarkIcon('bookmark-outline');
            }
            else {
                set(ref(FIREBASE_DB, "/users/" + uid + "/bookmarks/"), [...updated, currBookmark]);
                setBookmarkIcon('bookmark');
            }
        }
        else {
            userData.bookmarks = [currBookmark]
            set(ref(FIREBASE_DB, "/users/" + uid), userData);
            setBookmarkIcon('bookmark');
        }
    }
    return (
        <ScrollView style={{ backgroundColor: '#fff' }}>
            <Modal
                transparent={true}
                visible={isModalVisible}>
                <View style={styles.modalBackground}>
                    <View style={styles.modalTextBox}>
                        <View style={styles.modalTextContainer}>
                            <Text style={{ fontSize: 16 }}>Bạn có thật sự muốn mua khóa học này không?</Text>
                        </View>
                        <View style={styles.textBoxButtons}>
                            <TouchableOpacity style={styles.yesButton}
                                onPress={handleOnBuy}>
                                <Text style={styles.buttonText}>Có</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.noButton} onPress={() => setModalVisible(false)}>
                                <Text style={styles.buttonText}>Không</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
            <View style={styles.container}>
                <Image source={{ uri: course.img }} style={styles.image} />
                <View style={styles.infosContainer}>
                    <View style={styles.titleContainer}>
                        <Text style={styles.title}>{course.name}</Text>
                        <TouchableOpacity style={{ marginRight: 10 }} onPress={handleOnBookmark}>
                            <Ionicons name={bookmarkIcon} color="#2f5771" size={30} />
                        </TouchableOpacity>
                    </View>
                    <Text style={{
                        fontSize: 17, color: "#2f5771", paddingVertical: 10,
                    }}>Mô tả khóa học: </Text>
                    <Text style={styles.info}>{course.content}</Text>
                    <View style={styles.infoContainer}>
                        <Text style={styles.infoHeader}>Thời hạn :  </Text>
                        <Text style={styles.info}>{course.time} tháng</Text>
                    </View>
                    <View style={styles.infoContainer}>
                        <Text style={styles.infoHeader}>Giá khóa học :  </Text>
                        <Text style={styles.info}>{formatted}</Text>
                    </View>
                    <View style={styles.buttonContainer}>
                        <TouchableOpacity style={styles.button} onPress={() => setModalVisible(true)}>
                            <Text style={styles.buttonText}>Mua khóa học</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </ScrollView >
    )
}

export default CourseDetails

const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    image: {
        width: 500,
        height: 300,
    },
    infosContainer: {
        padding: 15,
    },
    titleContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    title: {
        fontSize: 23,
        color: "#2f5771",
        fontWeight: 'bold',
        marginRight: 20,
        paddingVertical: 5,
    },
    info: {
        fontSize: 17,
        paddingRight: 8,
        color: '#151234'
    },
    buttonContainer: {
        paddingTop: 10,
        padding: 10,
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        alignItems: 'center',
    },
    button: {
        backgroundColor: '#00b3b3',
        padding: 15,
        borderRadius: 5,
    },
    buttonText: {
        color: '#151234',
        fontSize: 18,
    },
    infoHeader: {
        fontSize: 17,
        color: "#2f5771",
        paddingVertical: 10,
    },
    infoContainer: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    modalBackground: {
        flex: 1,
        backgroundColor: '#000000cc',
        alignItems: 'center',
        justifyContent: 'center',
    },
    modalTextBox: {
        borderRadius: 10,
        backgroundColor: '#fff',
        paddingVertical: 10,
        paddingBottom: 20,
        width: '66%',
        height: '20.5%',

    },
    modalTextContainer: {
        paddingLeft: 20,
        paddingBottom: 20,
        paddingTop: 20,
    },
    textBoxButtons: {
        justifyContent: 'space-around',
        width: "100%",
        height: "45%",
        flexDirection: 'row',
    },
    yesButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: "50%",
        backgroundColor: "#00b3b3",
        borderBottomLeftRadius: 10,
    },
    noButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: "50%",
        backgroundColor: "#b3b3b3",
        borderBottomRightRadius: 10,
    },
    buttonText: {
        fontSize: 18,
        color: 'white',
    }
})