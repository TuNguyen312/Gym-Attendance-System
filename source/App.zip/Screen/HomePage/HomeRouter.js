import Home from './Home';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import CourseList from './CourseList';
import PostList from './PostList';
import Notification from './Notificaton/Notification';
import CourseDetails from './CourseDetails';
import PostDetails from './PostDetails';
const Stack = createNativeStackNavigator();

export default function HomeRouter({ navigation, route }) {

    return (
        <Stack.Navigator initialRouteName='Home' >
            <Stack.Screen name='Home' component={Home} options={{ headerShown: false }} />
            <Stack.Screen name='Notification' component={Notification} />
            <Stack.Screen name="CourseList" component={CourseList} options={({ route }) => ({ title: route.params.name, headerBackTitleVisible: false })} />
            <Stack.Screen name="PostList" component={PostList} options={({ route }) => ({ title: route.params.name, headerBackTitleVisible: false })} />
            <Stack.Screen name='CourseDetails' component={CourseDetails} options={({ route }) => ({ title: route.params.name, headerBackTitleVisible: false })} />
            <Stack.Screen name='PostDetails' component={PostDetails} options={({ route }) => ({ title: route.params.name, headerBackTitleVisible: false })} />
        </Stack.Navigator>
    )
}