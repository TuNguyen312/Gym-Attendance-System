
import { createNativeStackNavigator } from '@react-navigation/native-stack';
const Stack= createNativeStackNavigator();

import Gym from './Gym';
import Fitness from './Fitness';
import BodyBuilding from './BodyBuilding';
export default function GymRouter({navigation,route}) {
    
    return (
        <Stack.Navigator initialRouteName='Gym' >
            <Stack.Screen name='Gym' component={Gym} />
            <Stack.Screen name='Fitness' component={Fitness} />
            <Stack.Screen name='BodyBuilding' component={BodyBuilding} />
            {/* WorkOut */}
            
        </Stack.Navigator>
    )}