import { StyleSheet, Text, View, ScrollView } from 'react-native';
import Course from '../../CoursePlanjs';
export default function Gym({ navigation }) {
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/gc1.jpg')}
                        title="Body Building"
                        dest="BodyBuilding"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/cc2.jpg')}
                        title="Fitness"
                        dest="Fitness"
                    />
                </View>



            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
})