import { StyleSheet, Text, View, ScrollView } from 'react-native';
import Course from '../../CoursePlanjs';
import Color from '../../../../Color';
export default function Fitness({ navigation }) {
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.title}>
                    <Text style={styles.content}>
                        Fitness là sự phù hợp, vừa vặn, cân đối, sung sức. Theo định nghĩa trong từ điển, Fitness chỉ một người sở hữu thể trạng cân đối, khỏe và có lối sống lành mạnh. Nghĩa chung của Fitness là một bộ môn thể thao giúp con người hoàn thiện cơ thể, giúp họ sống khỏe và tốt hơn.{'\n'}

                        Tập Fitness đem lại cho bạn một cơ thể hài hòa và cân đối, không quá to như tập Bodybuilding. Body Fitness nhấn mạnh vào vẻ đẹp thẩm mỹ của cơ thể và nét hài hòa của cơ bắp hơn là yếu tố kích thước cơ bắp.            </Text>
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/cc1.jpg')}
                        title="Gói làm quen"
                        time="1 tháng"
                        price="1000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/gc2.jpg')}
                        title="Gói khởi động"
                        time="3 tháng"
                        price="2700000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/cc3.jpg')}
                        title="Gói bền vững"
                        time="6 tháng"
                        price="5000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/gc4.jpg')}
                        title="Gói dài lâu"
                        time="12 tháng"
                        price="8000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>

            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
    title: {
        width: '100%',
        backgroundColor: Color.theme,
        marginVertical: 5,
        padding: 10,
        //marginHorizontal:10,
    },
    content: {
        fontSize: 15,
        //fontWeight:'bold',
    }
})