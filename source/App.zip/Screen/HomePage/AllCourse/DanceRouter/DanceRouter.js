
import { createNativeStackNavigator } from '@react-navigation/native-stack';
const Stack= createNativeStackNavigator();

import Aerobic from './Aerobic';
import Dance from './Dance';
import BodyCombat from './BodyCombat';
import Zumba from './Zumba';
export default function DanceRouter({navigation,route}) {
    
    return (
        <Stack.Navigator initialRouteName='Dance' >
            <Stack.Screen name='Dance' component={Dance} options={{headerTitle: 'Nhảy'}}/>
            <Stack.Screen name='Zumba' component={Zumba} />
            <Stack.Screen name='Aerobic' component={Aerobic} />
            <Stack.Screen name='BodyCombat' component={BodyCombat} />
            {/* WorkOut */}
            
        </Stack.Navigator>
    )}