import { StyleSheet, Text, View } from 'react-native';
import Course from '../../CoursePlanjs';
export default function Dance({ navigation }) {
    return (
        <View style={styles.container}>
            <View style={styles.coursecontainer}>
                <Course
                    img={require('../../../../assets/zumba1.jpg')}
                    title="Aerobic"
                    dest="Aerobic"
                />
            </View>
            <View style={styles.coursecontainer}>
                <Course
                    img={require('../../../../assets/dc1.jpg')}
                    title="Zumba"

                    dest="Zumba"
                />
            </View>
            <View style={styles.coursecontainer}>
                <Course
                    img={require('../../../../assets/bdc.jpg')}
                    title="BodyCombat"
                    dest="BodyCombat"
                />
            </View>


        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        //justifyContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
})