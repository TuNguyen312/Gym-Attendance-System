
import { createNativeStackNavigator } from '@react-navigation/native-stack';
const Stack= createNativeStackNavigator();


import HathaYoga from './HathaYoga';
import VinyasaYoga from './VinyasaYoga';
import IyengarYoga from './IyengarYoga';
import Yoga from './Yoga';
import KudaliniYoga from './Kudalini';
import AshtangaYoga from './AshtangaYoga';
export default function YogaRouter({navigation,route}) {
    
    return (
        <Stack.Navigator initialRouteName='Yoga' >
            <Stack.Screen name='Yoga' component={Yoga} />
            <Stack.Screen name='HathaYoga' component={HathaYoga} />
            <Stack.Screen name='VinyasaYoga' component={VinyasaYoga} />
            <Stack.Screen name='IyengarYoga' component={IyengarYoga} />
            <Stack.Screen name='KundaliniYoga' component={KudaliniYoga} />
            <Stack.Screen name='AshtangaYoga' component={AshtangaYoga} />
            {/* WorkOut */}
            
        </Stack.Navigator>
    )}