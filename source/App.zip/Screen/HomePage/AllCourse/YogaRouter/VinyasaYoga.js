import { StyleSheet, Text, View, ScrollView } from 'react-native';
import Course from '../../CoursePlanjs';
import Color from '../../../../Color';
export default function VinyasaYoga({ navigation }) {
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.title}>
                    <Text style={styles.content}>
                        Vinyasa là thể loại Yoga kết nối giữa chuyển động và hơi thở, tạo thành chuỗi các động tác chuyển tiếp nhẹ nhàng. Theo tiếng Ấn Độ, từ “Vinyasa” có nghĩa là “kết nối”. Từng chuyển động được kết hợp nhịp nhàng với từng nhịp hít vào, thở ra. Mỗi buổi tập “Vinyasa” sẽ kết thúc bằng tư thể nghỉ ngơi. Ngoài ra, ở lớp tập Vinyasa, các giáo viên có thể xây dựng một bài tập thiên về tinh thần nhiều hơn khi kết hợp giữa các bài tập thở, niệm chú (OHM) và thiền.
                    </Text>
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/vinya.jpg')}
                        title="Gói làm quen"
                        time="1 tháng"
                        price="1000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/yc2.jpg')}
                        title="Gói khởi động"
                        time="3 tháng"
                        price="2700000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/vinya3.jpg')}
                        title="Gói bền vững"
                        time="6 tháng"
                        price="5000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/yc4.jpg')}
                        title="Gói dài lâu"
                        time="12 tháng"
                        price="8000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>

            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
    title: {
        width: '100%',
        backgroundColor: Color.theme,
        marginVertical: 5,
        padding: 10,
        //marginHorizontal:10,
    },
    content: {
        fontSize: 15,
        //fontWeight:'bold',
    }
})