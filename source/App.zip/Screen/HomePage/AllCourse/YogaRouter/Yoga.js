import { StyleSheet, Text, View, ScrollView } from 'react-native';
import Course from '../../CoursePlanjs';
export default function Yoga({ navigation }) {
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/hatha1.jpg')}
                        title="Hatha Yoga"
                        dest="HathaYoga"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/yc2.jpg')}
                        title="Vinyasa Yoga"
                        dest="VinyasaYoga"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/Iyengar2.jpg')}
                        title="Iyengar Yoga"
                        dest="IyengarYoga"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/Kuda2.jpg')}
                        title="Kundalini Yoga"
                        dest="KundaliniYoga"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/ashta1.jpg')}
                        title="Ashtanga Yoga"
                        dest="AshtangaYoga"
                    />
                </View>


            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
})