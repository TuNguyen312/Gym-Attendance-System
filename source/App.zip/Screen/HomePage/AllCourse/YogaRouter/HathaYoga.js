import { StyleSheet, Text, View, ScrollView } from 'react-native';
import Course from '../../CoursePlanjs';
import Color from '../../../../Color';
export default function HathaYoga({ navigation }) {
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.title}>
                    <Text style={styles.content}>
                        Hatha Yoga là loại Yoga nhẹ nhàng, phù hợp cho người mới bắt đầu tập hoặc cho những người rèn luyện Yoga đã thành thạo thư giãn. Với thể loại này, bạn sẽ được học các thế yoga cơ bản, luyện thở, kỹ thuật thư giãn và thiền.
                    </Text>
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/hatha1.jpg')}
                        title="Gói làm quen"
                        time="1 tháng"
                        price="1000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/hatha2.jpg')}
                        title="Gói khởi động"
                        time="3 tháng"
                        price="2700000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/yc3.jpg')}
                        title="Gói bền vững"
                        time="6 tháng"
                        price="5000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/hatha4.jpg')}
                        title="Gói dài lâu"
                        time="12 tháng"
                        price="8000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>

            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
    title: {
        width: '100%',
        backgroundColor: Color.theme,
        marginVertical: 5,
        padding: 10,
        //marginHorizontal:10,
    },
    content: {
        fontSize: 15,
        fontWeight: 'bold',
    }
})