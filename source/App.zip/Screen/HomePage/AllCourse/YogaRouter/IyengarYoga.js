import { StyleSheet, Text, View, ScrollView } from 'react-native';
import Course from '../../CoursePlanjs';
import Color from '../../../../Color';
export default function IyengarYoga({ navigation }) {
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.title}>
                    <Text style={styles.content}>
                        Iyengar Yoga là một trường phái Yoga được xây dựng dựa trên sự “đồng nhất” (Alignment). Song lớp tập Iyengar lại không theo chuỗi như Vinyasa. Những thế yoga trong Iyenga được giữ lâu hơn. Đồng thời, sau mỗi nhịp thở, bạn lại ép động tác sâu thêm một chút nữa. Giáo viên sẽ sử dụng nhiều dụng cụ hỗ trợ như chăn, gạch …trong quá trình tập để đảm bảo bạn thực hiện đúng tư thế.

                        Tập luyện Iyengar sẽ giúp xây dựng sức mạnh, sự nhanh nhẹn và cân bằng.
                    </Text>
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/Iyengar1.jpg')}
                        title="Gói làm quen"
                        time="1 tháng"
                        price="1000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/Iyengar2.jpg')}
                        title="Gói khởi động"
                        time="3 tháng"
                        price="2700000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/Iyengar3.jpg')}
                        title="Gói bền vững"
                        time="6 tháng"
                        price="5000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/Iyengar4.jpg')}
                        title="Gói dài lâu"
                        time="12 tháng"
                        price="8000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>

            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
    title: {
        width: '100%',
        backgroundColor: Color.theme,
        marginVertical: 5,
        padding: 10,
        //marginHorizontal:10,
    },
    content: {
        fontSize: 15,
        //fontWeight:'bold',
    }
})