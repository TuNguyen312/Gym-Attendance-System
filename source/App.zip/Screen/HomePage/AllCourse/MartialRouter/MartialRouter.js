
import { createNativeStackNavigator } from '@react-navigation/native-stack';
const Stack= createNativeStackNavigator();


import Boxing from './Boxing';
import Martial from './Martial';
import MuayThai from './MuayThai';

export default function MartialRouter({navigation,route}) {
    
    return (
        <Stack.Navigator initialRouteName='Martial' >
            <Stack.Screen name='Martial' component={Martial} options={{headerTitle: 'Võ'}}/>
            <Stack.Screen name='MuayThai' component={MuayThai} />
            <Stack.Screen name='Boxing' component={Boxing} />
            {/* WorkOut */}
            
        </Stack.Navigator>
    )}