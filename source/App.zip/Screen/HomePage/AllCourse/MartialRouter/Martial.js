import { StyleSheet, Text, View } from 'react-native';
import Course from '../../CoursePlanjs';
export default function Martial({ navigation }) {
    return (
        <View style={styles.container}>
            <View style={styles.coursecontainer}>
                <Course
                    img={require('../../../../assets/mc1.jpg')}
                    title="Khóa tập MuayThai"
                    dest="MuayThai"
                />
            </View>
            <View style={styles.coursecontainer}>
                <Course
                    img={require('../../../../assets/bc1.jpg')}
                    title="Khóa tập Boxing"
                    dest="Boxing"
                />
            </View>


        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        //justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
})