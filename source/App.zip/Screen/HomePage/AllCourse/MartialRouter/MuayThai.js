import { StyleSheet, Text, View, ScrollView } from 'react-native';
import Course from '../../CoursePlanjs';
import Color from '../../../../Color';
export default function MuayThai({ navigation }) {
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.title}>
                    <Text>
                        Võ Muay Thái là một môn võ cổ truyền có lịch sử lâu đời và đến nay, trở thành bộ môn thể thao phổ biến rộng rãi tại Thái Lan. Muay Thái là bộ môn võ thuật kết hợp các động tác tấn công bằng tay, chân, cùi chỏ và dùng khuỷu tay, sử dụng toàn bộ cơ thể và tận dụng tối đa khả năng của mọi bộ phận để đánh gục và tấn công đối thủ. Muay Thái là sự kết hợp hoàn hảo giữa các môn võ khác, sử dụng tay, nắm đấm như boxing, chân như Karate và các đòn xoay, khóa như Judo, Aikido. Do đó, Muay Thái luôn được những võ sư và vận động viên võ thuật chuyên nghiệp sử dụng và luyện tập.
                    </Text>
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/mc1.jpg')}
                        title="Gói làm quen"
                        time="1 tháng"
                        price="1000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/mc2.jpg')}
                        title="Gói khởi động"
                        time="3 tháng"
                        price="2700000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/mc3.jpg')}
                        title="Gói bền vững"
                        time="6 tháng"
                        price="5000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/mc4.jpg')}
                        title="Gói dài lâu"
                        time="12 tháng"
                        price="8000000"
                        detail="true"
                        dest="Payment"
                    />
                </View>

            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
    title: {
        width: '100%',
        backgroundColor: Color.theme,
        marginVertical: 5,
        padding: 10,
        //marginHorizontal:10,
    },
    content: {
        fontSize: 15,
        //fontWeight:'bold',
    }
})