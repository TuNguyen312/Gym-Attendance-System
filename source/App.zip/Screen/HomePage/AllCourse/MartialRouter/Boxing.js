import { StyleSheet, Text, View, ScrollView } from 'react-native';
import Course from '../../CoursePlanjs';
import Color from '../../../../Color';
export default function Boxing({ navigation }) {
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.title}>
                    <Text>
                        Boxing hay còn gọi là quyền anh hoặc đấm bốc là một môn thể thao có tính đối kháng cao, bao gồm những động tác kỹ thuật cơ bản thực hiện bằng cả hai tay như đấm thẳng, đấm vòng và đấm móc. Ngoài đôi tay, thì boxing cũng cần đến sự di chuyển linh hoạt và khéo léo của đôi chân và cơ thể.
                        {'\n'}
                        Di chuyển, né đòn và phản đòn là những yếu tố cần có khi tham gia môn thể thao boxing. Trong những trận đấu boxing chuyên nghiệp, bạn sẽ sử dụng các kỹ thuật để đấm vào những vị trí khiến cho đối thủ gục xuống là bạn đã chiến thắng.
                    </Text>
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/bc1.jpg')}
                        title="Gói làm quen"
                        time="1 tháng"
                        price="1000000"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/bc2.jpg')}
                        title="Gói khởi động"
                        time="3 tháng"
                        price="2700000"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/bc3.jpg')}
                        title="Gói bền vững"
                        time="6 tháng"
                        price="5000000"
                        dest="Payment"
                    />
                </View>
                <View style={styles.coursecontainer}>
                    <Course
                        img={require('../../../../assets/bc4.jpg')}
                        title="Gói dài lâu"
                        time="12 tháng"
                        price="8000000"
                        dest="Payment"
                    />
                </View>

            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    coursecontainer: {
        width: '45%',
        margin: '1%'
    },
    title: {
        width: '100%',
        backgroundColor: Color.theme,
        marginVertical: 5,
        padding: 10,
        //marginHorizontal:10,
    },
    content: {
        fontSize: 15,
        //fontWeight:'bold',
    }
})