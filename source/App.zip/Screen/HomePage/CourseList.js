import { StyleSheet, FlatList, Alert, View } from 'react-native'
import { useNavigation, useRoute } from '@react-navigation/native'
import React, { useContext } from 'react'
import Course from '../../components/Course.js';
const CourseList = () => {
    const route = useRoute();
    const { courses } = route.params;
    const navigation = useNavigation();
    return (
        <View style={{ flex: 1 }}>
            <FlatList
                style={{ flex: 1 }}
                data={courses}
                keyExtractor={course => course.id}
                renderItem={({ item, index }) => (
                    < Course
                        course={item}
                    />
                )
                }
                numColumns={2}
            />
        </View>
    )
}

export default CourseList

const styles = StyleSheet.create({})