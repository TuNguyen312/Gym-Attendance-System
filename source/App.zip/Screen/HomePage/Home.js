import { StyleSheet, Text, View, Image, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Color from '../../Color';
import Post from '../../components/Post';
import Swiper from 'react-native-swiper';
import Sign from '../../components/Sign';
import React, { useState, useEffect, useContext } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { AuthContext } from '../../AuthContext';
import { FIREBASE_DB } from '../../Firebase';
import { ref, onValue } from "firebase/database";

const windowHeight = Dimensions.get('window').height;

export default function Home() {
    const navigation = useNavigation();
    const { uid } = useContext(AuthContext);
    const [name, setName] = useState('');
    const [courses, setCourses] = useState([]);
    const [instructions, setInstructions] = useState([]);
    const [news, setNews] = useState([]);
    const [nutritions, setNutritions] = useState([]);
    const [isLoading, setLoading] = useState(false);
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'post/'), (snapshot) => {
            const data = snapshot;
            setInstructions(data.val().instruction);
            setNews(data.val().news);
            setNutritions(data.val().nutrition);
        })
    }, [FIREBASE_DB])
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'users/' + uid), (snapshot) => {
            const data = snapshot;
            setName(data.val().name);
        })
    }, [FIREBASE_DB])
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'courses'), (snapshot) => {
            const data = snapshot;
            setCourses(data.val())
            setLoading(true);
        })
    }, [FIREBASE_DB])
    const PostHeader = ({ title, handleOnAllPress }) => {
        return (
            <View style={styles.postheader}>
                <Text style={styles.title}>
                    {title}
                </Text>
                <TouchableOpacity onPress={handleOnAllPress}>
                    <Text style={styles.extent}>Xem tất cả</Text>
                </TouchableOpacity>
            </View>
        );
    };

    return (
        <SafeAreaView style={styles.container}>
            <ScrollView >
                <View style={styles.headerContainer}>
                    <Text style={styles.name}>Xin chào, {name}</Text>
                    {/* <TouchableOpacity onPress={() => navigation.navigate("Notification")}>
                        <Ionicons name='notifications' size={30} />
                    </TouchableOpacity> */}
                </View>
                <View sttyle={styles.signcontainer}>
                    <PostHeader
                        title="Đăng ký tự tập"
                        handleOnAllPress={() => navigation.navigate("CourseList", { name: 'Đăng ký tự tập', courses: courses.selfpractice })}
                    />
                    {isLoading &&
                        <Swiper loop={true} style={styles.signswiper} autoplay>
                            {courses.selfpractice.map(practice => (
                                <Sign
                                    key={practice.id}
                                    course={practice}
                                />
                            ))
                            }
                        </Swiper>}
                </View>
                <View style={styles.coursecontainer}>
                    <Text style={styles.title}>
                        Các khóa học
                    </Text>
                    <View style={styles.row}>
                        <TouchableOpacity style={styles.course} onPress={() => navigation.navigate("CourseList", { name: "Đăng ký khóa Gym", courses: courses.gym })}>
                            <Text style={styles.coursetype}>
                                Gym
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.course} onPress={() => navigation.navigate("CourseList", { name: "Đăng ký khóa Yoga", courses: courses.yoga })}>
                            <Text style={styles.coursetype}>
                                Yoga
                            </Text>
                        </TouchableOpacity>

                    </View>
                    <View style={styles.row}>
                        <TouchableOpacity style={styles.course} onPress={() => navigation.navigate("CourseList", { name: "Đăng ký khóa võ", courses: courses.martial })}>
                            <Text style={styles.coursetype}>
                                Võ thuật
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.course} onPress={() => navigation.navigate("CourseList", { name: "Đăng ký khóa nhảy", courses: courses.dance })}>
                            <Text style={styles.coursetype}>
                                Nhảy nghệ thuật
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={styles.postcontainer}>
                    <PostHeader
                        title="Tin tức mới"
                        handleOnAllPress={() => navigation.navigate("PostList", { name: "Tin tức mới", posts: news })}
                    />
                    <View style={styles.postcontent}>
                        <ScrollView horizontal={true} >
                            {news.map(news => (
                                <Post
                                    key={news.id}
                                    img={{ uri: news.img }}
                                    title={news.title}
                                    date={news.date}
                                    handleOnPress={() => navigation.navigate("PostDetails", { item: news, name: news.title })}
                                />
                            ))
                            }
                        </ScrollView>
                    </View>
                </View>
                <View style={styles.postcontainer}>
                    <PostHeader
                        title="Hướng dẫn tập luyện"
                        handleOnAllPress={() => navigation.navigate("PostList", { name: "Hướng dẫn tập luyện", posts: instructions })}
                    />
                    <View style={styles.postcontent}>
                        <ScrollView horizontal={true} >
                            {instructions.map(instruction => (
                                <Post
                                    key={instruction.id}
                                    img={{ uri: instruction.img }}
                                    title={instruction.title}
                                    date={instruction.date}
                                    handleOnPress={() => navigation.navigate("PostDetails", { item: instruction, name: instruction.title })}
                                />
                            ))
                            }
                        </ScrollView>
                    </View>
                </View>
                <View style={styles.postcontainer}>
                    <PostHeader
                        title="Chế độ dinh dưỡng"
                        handleOnAllPress={() => navigation.navigate("PostList", { name: 'Chế độ dinh dưỡng', posts: nutritions })}
                    />
                    <View style={styles.postcontent}>
                        <ScrollView horizontal={true} >
                            {nutritions.map(nutrition => (
                                <Post
                                    key={nutrition.id}
                                    img={{ uri: nutrition.img }}
                                    title={nutrition.title}
                                    date={nutrition.date}
                                    handleOnPress={() => navigation.navigate("PostDetails", { item: nutrition, name: nutrition.title })}
                                />
                            ))
                            }
                        </ScrollView>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white"
    },
    signcontainer: {
        margin: 10,
        width: 100,

    },
    signswiper: {
        height: windowHeight * 0.3,
        marginTop: 10,
        marginBottom: 20,

    },
    headerContainer: {
        borderRadius: 10,
        paddingHorizontal: 18,
        backgroundColor: Color.theme,
        width: '100',
        padding: 10,
        height: 70,
        marginBottom: 30,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    name: {
        color: Color.text,
        fontWeight: 'bold',
        fontSize: 20
    },
    row: {
        flexDirection: 'row',
        width: '100%',

        justifyContent: 'center',

    },
    coursecontainer: {
        marginVertical: 10,
    },
    course: {
        backgroundColor: Color.button,
        width: '45%',
        height: 70,
        borderRadius: 10,
        marginTop: 10,
        marginHorizontal: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    coursetype: {
        color: "white",
        fontWeight: "bold",
        fontSize: 20,
    },
    postcontainer: {
        marginVertical: 10,
    },
    postheader: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
        marginRight: 20
    },

    title: {
        fontSize: 20,
        fontWeight: 'bold',
        color: Color.title,
        paddingHorizontal: 10,
    },
    extent: {
        color: Color.button,
        fontSize: 13,
        fontWeight: 'bold',
        //justifyContent:"center",
    },

});