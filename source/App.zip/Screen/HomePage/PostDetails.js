import { StyleSheet, Text, View, Image, ScrollView } from 'react-native'
import { useRoute } from '@react-navigation/native';
import React from 'react'

const PostDetails = () => {
    const route = useRoute();
    const { item } = route.params;
    return (
        <ScrollView style={{ backgroundColor: '#fff', flex: 1 }}>
            <View style={styles.container}>
                <Image source={{ uri: item.img }} style={styles.image} />
                <View style={styles.infosContainer}>
                    <Text style={styles.title}>{item.title}</Text>
                    <Text style={styles.content}>{item.content}</Text>
                </View>
            </View>
        </ScrollView>
    )
}

export default PostDetails

const styles = StyleSheet.create({
    container:
    {
        // flex: 1,
        alignItems: 'center',
        // backgroundColor: '#fff',
    },
    image: {
        width: 500,
        height: 300,
    },
    infosContainer: {
        padding: 15,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginRight: 20,
        paddingVertical: 5,
        color: "#2f5771"
    },
    content: {
        fontSize: 18,
        color: "#151234"
    }
})