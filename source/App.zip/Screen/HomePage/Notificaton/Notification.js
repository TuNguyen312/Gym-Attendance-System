import { StyleSheet, Text, View,Button,Image,ScrollView,TouchableOpacity,Dimensions } from 'react-native';
import Color from '../../../Color';
import NotiPost from './NotiPost';
export default function Notification ({navigation}) {
    return (
        <ScrollView style={styles.container}> 
             
            <NotiPost
                title="title"
                content="content"
            />  
            <NotiPost
                title="title"
                content="content"
            /> 
        </ScrollView>
)}
const styles = StyleSheet.create({
    container:{
        flex: 1,
        // alignContent: 'center',
        // justifyContent: 'center',
        padding:20
    },
    
})