import { StyleSheet, Text, View,Button,Image,ScrollView,TouchableOpacity,Dimensions } from 'react-native';
import Color from '../../../Color';
export default function NotiPost ({title,content}) {
    return (
         
    <View style={styles.notiContainer}>
        <Text style={styles.title}>
            {title}
        </Text>
        <Text style={styles.content}>
            {content}
        </Text>
    </View>    
            
        
)}
const styles = StyleSheet.create({
    
    notiContainer:{
        backgroundColor:Color.theme,
        borderRadius:10,
        padding:10,
        marginBottom:20,
        
        elevation: 5, 
        //elevation:10
    },
    title:{
        fontWeight: 'bold',
        fontSize:20,
        marginBottom:5
    },
    line: {
        height: 1,
        width: '100%',
        backgroundColor: '#ccc' 
      },
    benefitcontainer:{
        padding:10,
    },
})