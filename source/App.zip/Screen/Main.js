import React from 'react';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import HomeRouter from './HomePage/HomeRouter';
import UserRouter from './UserPage/UserRouter';
import History from './History';

const Tab = createBottomTabNavigator();
export default function Main({ navigation }) {
    return (
        <Tab.Navigator screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color }) => {
                let iconname;
                color = focused ? '#2f5771' : '#151234';
                if (route.name === "HomeRouter") {
                    iconname = "home";
                }
                if (route.name === "History") {
                    iconname = "calendar";
                }
                if (route.name === 'UserProfile') {
                    iconname = 'account';
                }
                return <Icon name={iconname} size={30} color={color} />;
            },
            tabBarInactiveTintColor: '#151234',
            tabBarActiveTintColor: '#2f5771'
        })
        }>
            <Tab.Screen name="HomeRouter" component={HomeRouter} options={{ headerShown: false, tabBarLabel: "Home" }} />
            <Tab.Screen name="History" component={History} options={{ headerTitle: "Lịch sử tập", tabBarLabel: "History" }} />
            <Tab.Screen name="UserProfile" component={UserRouter} options={{ headerShown: false }} />
        </Tab.Navigator>

    );
}
