import { StyleSheet, Text, View, Button, Image, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Color from '../../../Color';

export default function Silver({ navigation }) {
    return (
        <View style={styles.container}>
            <View style={styles.benefitcontainer}>
                <View style={styles.line} />
                <View style={styles.benefit}>
                    <Icon name="alert-circle" size={30} color={Color.button} />
                    <Text style={styles.content}>
                        Điều kiện kích hoạt: {"\n"}
                        Khách hàng đã đăng ký các khóa tập có tổng giá trị hơn 10 triệu
                    </Text>
                </View>
                <View style={styles.line} />
                <View style={styles.benefit}>
                    <Icon name="sale" size={30} color={Color.button} />
                    <Text style={styles.content}>
                        Khách hàng được giảm 10% khi đăng ký các khóa học
                    </Text>
                </View>

            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        // alignContent: 'center',
        // justifyContent: 'center',
    },
    line: {
        marginVertical: 5,
        height: 1,
        width: '100%',
        backgroundColor: '#ccc'
    },
    benefitcontainer: {
        paddingHorizontal: 10,
    },
    benefit: {
        flexDirection: 'row',
        width: '100%',
        //justifyContent:'center',
        alignItems: 'center',
    },
    content: {
        marginHorizontal: 5,
        width: '90%'
    }
})