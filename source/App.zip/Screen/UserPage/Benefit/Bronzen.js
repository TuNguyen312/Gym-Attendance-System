import { StyleSheet, Text, View, Button, Image, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
export default function Bronze({ navigation }) {
    return (
        <View style={styles.container}>
            <View style={styles.benefitcontainer}>
                <View style={styles.line} />
                <Text>
                    Không có ưu đãi
                </Text>

            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        // justifyContent: 'center',
        alignItems: 'center',
    },
    line: {
        height: 1,
        width: '100%',
        backgroundColor: '#ccc',
        justifyContent: 'center',
        alignItems: 'center',
    },
    benefitcontainer: {
        padding: 10,
    }
})