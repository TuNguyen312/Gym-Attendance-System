import { StyleSheet, Text, View, Alert, Image, ScrollView, TouchableOpacity, FlatList, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Color from '../../Color';
import UserCourse from './UserCourse';
import { useContext, useState, useEffect } from 'react';
import { ref, onValue } from "firebase/database";
import { FIREBASE_DB } from '../../Firebase';
import { AuthContext } from '../../AuthContext';
import moment from 'moment';
export default function Account({ navigation }) {
    const { setAuthenticated, uid, setUid } = useContext(AuthContext);
    const [userData, setUserData] = useState({});
    const [courses, setCourses] = useState([]);
    const [isModalVisible, setModalVisible] = useState(false);
    const [rank, setRank] = useState("");
    const [isEmpty, setEmpty] = useState(true);
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'users/' + uid), (snapshot) => {
            const data = snapshot;
            setUserData(data.val());
            const today = new Date(moment().format("YYYY-MM-DD"))
            var tempCourse = [];
            if (data.val().courses) {
                data.val().courses.forEach((course) => {
                    const start = new Date(course.start);
                    const end = new Date(course.end);
                    if ((today <= end) && (today >= start)) {
                        tempCourse = [...tempCourse, course];
                    }
                });
                setCourses(tempCourse);
                setEmpty(false);
            }
            else {
                setCourses([]);
                setEmpty(true);
            }
            const totalSpend = data.val().totalSpend;
            if (totalSpend <= 10000000) {
                setRank("Đồng");
            }
            else if (totalSpend > 10000000 && totalSpend <= 20000000) {
                setRank("Bạc");
            }
            else {
                setRank("Vàng");
            }
        })
    }, [FIREBASE_DB])
    const handleOnLogOut = () => {
        setModalVisible(false);
        setUid('');
        setAuthenticated(false);
    }
    return (
        <SafeAreaView style={styles.container}>
            <Modal
                transparent={true}
                visible={isModalVisible}>
                <View style={styles.modalBackground}>
                    <View style={styles.modalTextBox}>
                        <View style={styles.modalTextContainer}>
                            <Text style={{ fontSize: 16 }}>Bạn có thật sự muốn đăng xuất không?</Text>
                        </View>
                        <View style={styles.textBoxButtons}>
                            <TouchableOpacity style={styles.yesButton}
                                onPress={handleOnLogOut}>
                                <Text style={styles.buttonText}>Có</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.noButton} onPress={() => setModalVisible(false)}>
                                <Text style={styles.buttonText}>Không</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
            <View style={styles.contentcontainer}>
                <TouchableOpacity style={styles.user} onPress={() => navigation.navigate('UserInfo')}>
                    <Image source={{ uri: userData.image }}
                        style={styles.avatar} />
                    <View style={styles.info}>
                        <Text style={styles.username}>{userData.name}</Text>
                        <Text style={styles.rank}>Thành viên hạng: {rank}</Text>
                        <Text>Chi tiết &#8250;</Text>
                    </View>
                </TouchableOpacity>
            </View>
            <View styles={styles.headercontainer}>
                <Text style={styles.header}>
                    Các khóa học hiện tại
                </Text>
            </View>
            {!isEmpty
                ? <FlatList
                    data={courses}
                    keyExtractor={course => course.course_id}
                    renderItem={({ item }) => (
                        < UserCourse
                            id={item.course_id}
                            coursename={item.name}
                            startday={item.start}
                            expireday={item.end}
                            price={item.price}
                        />
                    )}
                />
                : <View style={{ justifyContent: 'center', alignItems: 'center', paddingVertical: 102, }}>
                    <Text style={{ fontSize: 17 }}>
                        Bạn chưa mua khóa học nào cả
                    </Text>
                </View>
            }
            <TouchableOpacity style={styles.function} onPress={() => navigation.navigate('CoursePaid')}>
                <Icon name='history' size={20} color='white' />
                <Text style={styles.textfunction}>
                    Các khóa học đã mua &#8250;
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.function} onPress={() => navigation.navigate('Bookmarks')}>
                <Icon name='bookmark' size={20} color='white' />
                <Text style={styles.textfunction}>
                    Các khóa học đã lưu &#8250;
                </Text>

            </TouchableOpacity>
            <TouchableOpacity style={styles.function} onPress={() => navigation.navigate('Benefit', { totalSpend: userData.totalSpend, rank: rank })}>
                <Ionicons name="gift" size={20} color='white' />
                <Text style={styles.textfunction}>
                    Quyền lợi thành viên &#8250;
                </Text>

            </TouchableOpacity>
            {/* <TouchableOpacity style={styles.function} onPress={() => navigation.navigate('Setting')}>
                <Icon name='settings' size={20} color='white' />
                <Text style={styles.textfunction}>
                    Cài đặt &#8250;
                </Text>

            </TouchableOpacity> */}
            <TouchableOpacity style={styles.function} onPress={() => setModalVisible(true)}>
                <Ionicons name='log-out' size={20} color='white' />
                <Text style={styles.textfunction}>
                    Đăng xuất &#8250;
                </Text>

            </TouchableOpacity>
        </SafeAreaView >
    );
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white"
    },
    contentcontainer: {
        margin: 10,
        padding: 10,
        borderRadius: 10,
        backgroundColor: Color.theme,
        elevation: 5
    },
    main: {
        margin: 10,
    },
    user: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    avatar: {
        width: 80,
        height: 80,
        borderRadius: 40,
        marginHorizontal: 10,
    },
    username: {
        fontSize: 20,
        color: '#000',
        fontWeight: 'bold',
    },
    info: {
        //display: "flex",
        //flexDirection: 'column',
    },
    headercontainer: {
        padding: 10,
        marginTop: 40,
    },
    header: {
        paddingLeft: 5,
        margin: 5,
        color: Color.button,
        fontWeight: 'bold',
        fontSize: 18,
    },
    coursecontainer: {
        width: '100',
        height: '30%',
    },

    function: {
        display: 'flex',
        flexDirection: "row",
        backgroundColor: Color.button,
        margin: 5,
        borderRadius: 10,
        padding: 10,
    },
    textfunction: {
        color: "white",
        marginLeft: 10,
    },
    logout: {
        margin: 10,
        //fontSize:20
    },
    modalBackground: {
        flex: 1,
        backgroundColor: '#000000cc',
        alignItems: 'center',
        justifyContent: 'center',
    },
    modalTextBox: {
        borderRadius: 10,
        backgroundColor: '#fff',
        paddingVertical: 10,
        paddingBottom: 20,
        width: '66%',
        height: '20.5%',

    },
    modalTextContainer: {
        paddingLeft: 20,
        paddingBottom: 20,
        paddingTop: 20,
    },
    textBoxButtons: {
        justifyContent: 'space-around',
        width: "100%",
        height: "45%",
        flexDirection: 'row',
    },
    yesButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: "50%",
        backgroundColor: "#00b3b3",
        borderBottomLeftRadius: 10,
    },
    noButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: "50%",
        backgroundColor: "#b3b3b3",
        borderBottomRightRadius: 10,
    },
    buttonText: {
        fontSize: 18,
        color: 'white',
    }
});