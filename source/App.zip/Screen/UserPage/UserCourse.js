import { StyleSheet, Text, View, Button, Image, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import Color from '../../Color';
export default function UserCourse(props) {
    const formatted = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(props.price);
    return (
        <View style={styles.course}>
            <View style={styles.courseinfo} >
                <Text style={styles.coursename}>
                    Khóa: {props.coursename}
                </Text>
                {/* <Text>
                    Id: {props.id}
                </Text> */}
                <Text style={styles.day}>
                    Ngày bắt đầu: {props.startday}
                </Text>
                <Text style={styles.day}>
                    Ngày kết thúc: {props.expireday}
                </Text>
            </View>
            <Text style={styles.price}>
                {formatted}
            </Text>
        </View>
    )
}
const styles = StyleSheet.create({
    course: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        margin: 10,
        padding: 10,
        borderRadius: 10,
        backgroundColor: Color.theme,
        elevation: 5
    },
    coursename: {
        fontWeight: "bold",
        fontSize: 18,
    },
    day: {
        fontSize: 16,
    },
    price: {
        marginTop: 40,
        fontSize: 20
    },

})