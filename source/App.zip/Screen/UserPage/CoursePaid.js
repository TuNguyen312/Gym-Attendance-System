import { StyleSheet, FlatList, View, Text, TouchableOpacity } from 'react-native';
import Course from './UserCourse';
import { useNavigation } from '@react-navigation/native';
import { useContext, useState, useEffect } from 'react';
import { ref, onValue } from "firebase/database";
import { FIREBASE_DB } from '../../Firebase';
import { AuthContext } from '../../AuthContext';
export default function CoursePaid() {
    const navigation = useNavigation();
    const { uid } = useContext(AuthContext);
    const [courses, setCourses] = useState([]);
    const [isEmpty, setEmpty] = useState(true);
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'users/' + uid), (snapshot) => {
            const data = snapshot;
            if (data.val().courses) {
                setCourses(data.val().courses);
                setEmpty(false);
            }
            else {
                setCourses([]);
                setEmpty(true);
            }
        })
    }, [FIREBASE_DB])
    return (
        <View style={{ flex: 1 }}>
            {!isEmpty
                ? <FlatList
                    data={courses}
                    keyExtractor={course => course.course_id}
                    renderItem={({ item }) => (
                        <Course
                            id={item.course_id}
                            coursename={item.name}
                            startday={item.start}
                            expireday={item.end}
                            price={item.price}
                        />
                    )}
                />
                : <View style={{ flex: 1, backgroundColor: '#fff', justifyContent: 'center', alignItems: 'center' }}>
                    <Text style={{ fontSize: 20 }}>Bạn chưa mua khóa học nào cả</Text>
                    <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("Home")}>
                        <Text style={styles.buttonText}>Mua khóa học</Text>
                    </TouchableOpacity>
                </View>
            }
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        // alignContent: 'center',
        // justifyContent: 'center',
        padding: 20,
    },
    button: {
        marginTop: 15,
        backgroundColor: '#00b3b3',
        padding: 15,
        borderRadius: 5,
    },
    buttonText: {
        fontSize: 18,
        color: 'white',
    }
})