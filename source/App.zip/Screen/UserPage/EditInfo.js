import { StyleSheet, Text, View, Button, Image, ScrollView, TouchableOpacity, Dimensions } from 'react-native';

export default function EditInfo({ navigation }) {
    return (
        <View style={styles.container}>
            <Text>
                EditInfo  Screen
            </Text>
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20
    }
})