import { StyleSheet, Text, View, Button, Image, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import Color from '../../Color';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { useRoute } from '@react-navigation/native';
import Bronze from './Benefit/Bronzen';
import Silver from './Benefit/Silver';
import Gold from './Benefit/Gold';
import * as Progress from 'react-native-progress';
const Tab = createMaterialTopTabNavigator();

export default function Benefit() {
    const route = useRoute();
    const { totalSpend, rank } = route.params;
    const total = "20000000"
    // const million = total / 1000000
    const result = totalSpend / total
    const currFormatted = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(totalSpend)
    const totalFormatted = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(total)
    return (
        <View style={styles.container}>
            <View style={styles.rank}>
                <Text>
                    Thứ hạng hiện tại:
                </Text>
                <Text style={styles.ranktype}>
                    {rank}
                </Text>
            </View>
            <View style={styles.progress}>
                <Text style={styles.title}>
                    Số tiền đã tiêu để nâng hạng:
                </Text>
                <View style={styles.uprank}>
                    <Text style={styles.moneysum}>
                        {currFormatted}
                    </Text>
                    <Text style={styles.total}>
                        / {totalFormatted}
                    </Text>
                </View>
                <View style={styles.progressBar}>
                    <Progress.Bar progress={result} width={null} height={10} />
                </View>
            </View>
            <View style={styles.allbenefit}>
                <Text style={styles.title}>
                    Quyền lợi thành viên theo thứ bậc
                </Text>
            </View>
            <Tab.Navigator
                screenOptions={({ route }) => ({
                    tabBarLabel: ({ focused, color }) => {
                        const labelColor = focused ? '#188bf0' : color;
                        return <Text style={{ color: labelColor }}>{route.name}</Text>;
                    }, tabBarStyle: { borderRadius: 10 }

                })}

            >
                <Tab.Screen name="Đồng" component={Bronze} />
                <Tab.Screen name="Bạc" component={Silver} />
                <Tab.Screen name="Vàng" component={Gold} />
            </Tab.Navigator>

        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        //alignContent: 'center',
        //justifyContent: 'center',

    },
    rank: {
        backgroundColor: Color.theme,
        padding: 20,
        flexDirection: 'row',
    },
    title: {
        color: Color.title,
        fontWeight: 'bold',
        padding: 20,
    },
    tab: {
        color: 'black',
    },
    progress: {
        //paddingVertical:20,
    },
    progressBar: {
        paddingHorizontal: 20,
        marginTop: 10,
    },
    uprank: {
        flexDirection: 'row',
        paddingHorizontal: 20
    },
    ranktype: {
        fontWeight: 'bold',
        marginLeft: 10
    }
})