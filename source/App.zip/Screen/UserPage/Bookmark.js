import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import Color from '../../Color';
import { useNavigation } from '@react-navigation/native';
import { FIREBASE_DB } from '../../Firebase';
import { onValue, ref, set } from "firebase/database";
export default function Bookmark(props) {
    const navigation = useNavigation();
    const formatted = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(props.price);
    const handleOnBookmarkPress = (id) => {
        var courseInfo = {};
        onValue(ref(FIREBASE_DB, '/courses/' + props.category), (snapshot) => {
            const courses = snapshot.val();
            courses.forEach((course) => {
                if (course.id === id) {
                    courseInfo = course;
                }
            })
        }, {
            onlyOnce: true,
        });
        navigation.navigate("CourseDetails", { name: courseInfo.name, course: courseInfo });
    }
    return (
        <TouchableOpacity style={styles.course} onPress={() => handleOnBookmarkPress(props.id)}>
            <View>
                <Text style={styles.name}>
                    Khóa: {props.name}
                </Text>
                <Text style={styles.time}>
                    Thời hạn: {props.time} tháng
                </Text>
            </View>
            <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                <Text style={styles.price}>
                    {formatted}
                </Text>
            </View>
        </TouchableOpacity>
    )
}
const styles = StyleSheet.create({
    course: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        margin: 10,
        padding: 10,
        borderRadius: 10,
        backgroundColor: Color.theme,
        elevation: 5
    },
    name: {
        fontWeight: "bold",
        paddingVertical: 10,
        fontSize: 18,
    },
    time: {
        paddingBottom: 10,
        fontSize: 18,
    },
    price: {
        fontSize: 20
    },
})