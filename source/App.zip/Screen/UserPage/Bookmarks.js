import { StyleSheet, FlatList, View, Text } from 'react-native';
import Bookmark from './Bookmark';
import { useNavigation } from '@react-navigation/native';
import { useContext, useState, useEffect } from 'react';
import { ref, onValue } from "firebase/database";
import { FIREBASE_DB } from '../../Firebase';
import { AuthContext } from '../../AuthContext';
export default function Bookmarks() {
    const navigation = useNavigation();
    const { uid } = useContext(AuthContext);
    const [bookmarks, setBookmarks] = useState([]);
    const [isEmpty, setEmpty] = useState(true);
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'users/' + uid), (snapshot) => {
            const data = snapshot;
            if (data.val().bookmarks) {
                setBookmarks(data.val().bookmarks);
                setEmpty(false);
            }
            else {
                setBookmarks([]);
                setEmpty(true);
            }
        })
    }, [FIREBASE_DB])
    return (
        <View style={{ flex: 1 }}>
            {!isEmpty
                ? <FlatList
                    data={bookmarks}
                    keyExtractor={bookmark => bookmark.id}
                    renderItem={({ item }) => (
                        <Bookmark
                            id={item.id}
                            category={item.category}
                            name={item.name}
                            time={item.time}
                            price={item.price}
                        />
                    )}
                />
                : <View style={{ flex: 1, backgroundColor: '#fff', justifyContent: 'center', alignItems: 'center' }}>
                    <Text style={{ fontSize: 20 }}>Bạn chưa lưu khóa học nào cả</Text>
                </View>
            }
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
    },
    button: {
        marginTop: 15,
        backgroundColor: '#00b3b3',
        padding: 15,
        borderRadius: 5,
    },
    buttonText: {
        fontSize: 18,
        color: 'white',
    }
})