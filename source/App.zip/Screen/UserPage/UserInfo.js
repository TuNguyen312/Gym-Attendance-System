import { StyleSheet, Text, View, Image, TouchableOpacity, TextInput, ScrollView } from 'react-native';
import { useEffect, useContext, useState } from 'react';
import Icon from 'react-native-vector-icons/FontAwesome5';
import { FIREBASE_DB } from '../../Firebase';
import { ref, onValue, set } from "firebase/database";
import { AuthContext } from '../../AuthContext';
const Info = ({ title, type, content, isEdit, setEdit, handleOnEdit }) => {
    const [editText, setEditText] = useState('');
    useEffect(() => {
        setEditText(content);
    }, [content])
    return (
        <View style={styles.info}>
            <Text style={styles.title}>
                {title}
            </Text>
            <View style={[styles.editContainer, isEdit && { backgroundColor: "white" }]}>
                <TextInput
                    style={styles.editcontent}
                    placeholder={editText}
                    data={editText}
                    onChangeText={(text) => setEditText(text)}
                    editable={isEdit}
                >
                    {content}
                </TextInput>
                <TouchableOpacity style={styles.edit} onPress={() => handleOnEdit(editText, type, isEdit, setEdit)}>
                    <Icon name={isEdit ? "check" : "edit"} size={20} />
                </TouchableOpacity>
            </View>
        </View >
    );
};

export default function UserInfo({ navigation }) {
    const { uid } = useContext(AuthContext);
    const [userData, setUserData] = useState({});
    const [nameEdit, setNameEdit] = useState(false);
    const [emailEdit, setEmailEdit] = useState(false);
    const [phoneEdit, setPhoneEdit] = useState(false);
    const [addressEdit, setAddressEdit] = useState(false);
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'users/' + uid), (snapshot) => {
            const data = snapshot;
            setUserData(data.val());
        })
    }, [FIREBASE_DB])
    const handleOnEdit = (text, type, isEdit, setEdit) => {
        if (isEdit) {
            var updated = userData
            updated[type] = text;
            set(ref(FIREBASE_DB, 'users/' + uid), updated);
        }
        setEdit(!isEdit);
    }
    return (
        <ScrollView>
            <View style={styles.container}>
                <View style={styles.imgcontainer}>
                    <Image source={{ uri: userData.image }} style={styles.avatar} />
                </View>
                <Info
                    title="Họ và Tên:"
                    type='name'
                    content={userData.name}
                    isEdit={nameEdit}
                    setEdit={setNameEdit}
                    handleOnEdit={handleOnEdit}
                />
                <Info
                    title="Email:"
                    type='email'
                    content={userData.email}
                    isEdit={emailEdit}
                    setEdit={setEmailEdit}
                    handleOnEdit={handleOnEdit}
                />
                <Info
                    title="Số điện thoại:"
                    type='phone'
                    content={userData.phone}
                    isEdit={phoneEdit}
                    setEdit={setPhoneEdit}
                    handleOnEdit={handleOnEdit}
                />
                <Info
                    title="Địa chỉ:"
                    type='address'
                    content={userData.address}
                    isEdit={addressEdit}
                    setEdit={setAddressEdit}
                    handleOnEdit={handleOnEdit}
                />
            </View>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20
    },

    edit: {
        marginLeft: 10,
    },
    avatar: {
        width: 100,
        height: 100,
        paddingTop: 20,
        borderRadius: 50,
        margin: 10,
    },
    imgcontainer: {
        alignItems: 'center',

    },
    info: {
        flexDirection: 'row',
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 20,
    },
    title: {
        width: '25%',
        fontSize: 15,
        marginRight: 10,
    },
    editContainer: {
        width: '70%',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: 15,
        borderColor: 'gray',
        borderWidth: 1,
        borderRadius: 5,
        paddingHorizontal: 10,
    },
    editcontent: {
        width: '90%',
    },
    content: {
        width: '90%',
    }
})