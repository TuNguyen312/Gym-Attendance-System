import { createNativeStackNavigator } from '@react-navigation/native-stack';
const Stack = createNativeStackNavigator();
import Setting from "./Setting";
import UserInfo from "./UserInfo";
import Benefit from "./Benefit";
import CoursePaid from "./CoursePaid";
import Bookmarks from './Bookmarks';
import EditInfo from "./EditInfo";
import Account from "./Account";
export default function UserRouter() {
    return (

        <Stack.Navigator initialRouteName='Account' >
            <Stack.Screen name='Account' component={Account} options={{ headerShown: false }} />
            <Stack.Screen name='CoursePaid' component={CoursePaid} options={{ headerTitle: 'Các khóa học đã mua' }} />
            <Stack.Screen name='Bookmarks' component={Bookmarks} options={{ headerTitle: 'Các khóa học đã lưu' }} />
            <Stack.Screen name='Setting' component={Setting} options={{ headerTitle: 'Cài Đặt' }} />
            <Stack.Screen name='UserInfo' component={UserInfo} options={{ headerTitle: 'Hồ Sơ' }} />
            <Stack.Screen name='EditInfo' component={EditInfo} options={{ headerTitle: 'Chỉnh sửa thông tin' }} />
            <Stack.Screen name='Benefit' component={Benefit} options={{ headerTitle: 'Lợi ích thành viên' }} />
        </Stack.Navigator>
    )
}