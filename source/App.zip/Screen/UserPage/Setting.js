import { StyleSheet, Text, View, Alert, Switch, TouchableOpacity } from 'react-native';
import Color from '../../Color';
export default function Setting({ navigation }) {
    return (
        <View style={styles.container}>
            <View style={styles.modecontainer}>
                <Text style={styles.mode}>Dark Mode</Text>

                <Switch
                    value='false'
                //onValueChange={props.toggleSwitch}            
                />

            </View>
            <TouchableOpacity style={styles.logout}
                onPress={LogOut}>
                <Text style={styles.button}>
                    Đăng xuất
                </Text>
            </TouchableOpacity>
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-between',
        //paddingBottom:20
        //paddingHorizontal:20,
        padding: 20
    },
    modecontainer: {
        width: '100%',
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',

    },
    mode: {
        color: Color.button,
        fontWeight: 'bold'
    },
    logout: {
        //flex: 1,
        backgroundColor: Color.button,
        //marginBottom:20
    },
    button: {
        color: "white",
        padding: 20,
        fontWeight: "bold",
    }
})