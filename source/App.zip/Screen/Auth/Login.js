// Nguyen Le Hoang Tu 21521613
import { View, Image, StyleSheet, Text, Keyboard, TouchableWithoutFeedback, Alert } from 'react-native'
import React, { useState, useContext } from 'react'
import Logo from '../../components/Logo.js'
import AuthCustomInput from '../../components/AuthCustomInput.js';
import AuthCustomButton from '../../components/AuthCustomButton.js';
import CustomNavigateText from '../../components/CustomNavigateText.js';
import { FIREBASE_AUTH } from '../../Firebase.js';
import { AuthContext } from '../../AuthContext.js';
import { signInWithEmailAndPassword } from "firebase/auth";
export default function Login({ navigation }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const { setUid, setAuthenticated } = useContext(AuthContext);
    const handleOnLogin = () => {
        signInWithEmailAndPassword(FIREBASE_AUTH, email, password)
            .then((userCredential) => {
                const user = userCredential.user;
                console.log('User signed in!');
                console.log(user.uid);
                setUid(user.uid);
                setAuthenticated(true);
            })
            .catch((error) => {
                const errorCode = error.code;
                const errorMessage = error.message;
                Alert.alert(errorCode + ': ' + errorMessage);
                console.error(errorCode + ': ' + errorMessage);
            });
    };
    const handleOnSignup = () => {
        navigation.navigate('Signup');
    };
    return (
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
            <View style={styles.loginContainer}>
                <Logo
                    imageSource={require('../../assets/logo.png')}
                    text="Welcome"
                />
                <AuthCustomInput
                    iconName="mail-outline"
                    placeHolderText="Email"
                    setValue={setEmail}
                    secureTextEntry={false}
                />
                <AuthCustomInput

                    iconName="lock-closed-outline"
                    placeHolderText="Password"
                    setValue={setPassword}
                    secureTextEntry={true}
                />
                {/* <Text style={styles.forgot}>Forgot password?</Text> */}
                <AuthCustomButton
                    buttonText="LOG IN"
                    handleOnPress={handleOnLogin}
                />
                {/* <Text style={styles.orLogin}>Or login with</Text>
                <View style={styles.imagesContainer}>
                    <Image style={styles.loginImage} source={require('../../assets/facebook.png')} />
                    <Image style={styles.loginImage} source={require('../../assets/google.png')} />
                </View> */}
                <CustomNavigateText
                    text1="Don't have an account?"
                    text2="Sign up here!"
                    handleOnPress={handleOnSignup}
                />
            </View>
        </TouchableWithoutFeedback>
    );
}

const styles = StyleSheet.create({
    loginContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#b7e7ec',
    },
    forgot: {
        color: "#2f5771",
        paddingLeft: 200,
    },
    orLogin: {
        paddingTop: 20,
        paddingBottom: 10,
        fontSize: 18,
        fontWeight: 'bold',
    },
    imagesContainer: {
        flexDirection: 'row',
    },
    loginImage: {
        height: 50,
        width: 50,
        margin: 10,
    },
})