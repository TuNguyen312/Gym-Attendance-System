// Nguyen Le Hoang Tu 21521613
import { View, StyleSheet, Keyboard, TouchableWithoutFeedback, Alert } from 'react-native'
import React, { useState, useContext } from 'react'
import Logo from '../../components/Logo.js'
import AuthCustomInput from '../../components/AuthCustomInput.js';
import AuthCustomButton from '../../components/AuthCustomButton.js';
import CustomNavigateText from '../../components/CustomNavigateText.js';
import { AuthContext } from '../../AuthContext.js';
import { FIREBASE_AUTH, FIREBASE_DB } from '../../Firebase.js';
import { createUserWithEmailAndPassword } from "firebase/auth";
import { ref, set, Database } from 'firebase/database';
export default function Login({ navigation }) {
    const [userName, setUserName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPass, setConfirmPass] = useState("");
    const { setUid, setAuthenticated } = useContext(AuthContext);
    const handleOnSignup = () => {
        if (password === confirmPass) {
            createUserWithEmailAndPassword(FIREBASE_AUTH, email, password)
                .then((userCredential) => {
                    console.log('User account created & signed in!');
                    console.log(userCredential._tokenResponse.localId);
                    setUid(userCredential._tokenResponse.localId);
                    set(ref(FIREBASE_DB, '/users/' + userCredential._tokenResponse.localId), {
                        name: userName,
                        email: email,
                        image: "https://www.clipartkey.com/mpngs/m/152-1520367_user-profile-default-image-png-clipart-png-download.png",
                    })
                    setAuthenticated(true);
                })
                .catch(error => {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                    Alert.alert(errorCode + ': ' + errorMessage);
                    console.error(errorCode + ': ' + errorMessage);
                });
        }
        else {
            Alert.alert('Password and comfirm password do not match');
        }
    };
    const handleOnLogin = () => {
        navigation.navigate('Login');
    };
    return (
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
            <View style={styles.loginContainer}>
                <Logo
                    imageSource={require('../../assets/logo.png')}
                    text="Create new account"
                />
                <AuthCustomInput
                    iconName="person-outline"
                    placeHolderText="Enter name"
                    setValue={setUserName}
                    secureTextEntry={false}
                />
                <AuthCustomInput
                    iconName="mail-outline"
                    placeHolderText="Enter email"
                    setValue={setEmail}
                    secureTextEntry={false}
                />
                <AuthCustomInput
                    iconName="lock-closed-outline"
                    placeHolderText="Enter password"
                    setValue={setPassword}
                    secureTextEntry={true}
                />
                <AuthCustomInput
                    iconName="lock-closed-outline"
                    placeHolderText="Confirm password"
                    setValue={setConfirmPass}
                    secureTextEntry={true}
                />
                <AuthCustomButton
                    buttonText="CREATE"
                    handleOnPress={handleOnSignup}
                />
                <CustomNavigateText
                    text1="Already have an account?"
                    text2="Login now!"
                    handleOnPress={handleOnLogin}
                />
            </View>
        </TouchableWithoutFeedback>
    );
}

const styles = StyleSheet.create({
    loginContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#b7e7ec',
    },
    orLogin: {
        paddingTop: 20,
        paddingBottom: 10,
        fontSize: 18,
        fontWeight: 'bold',
    },
    imagesContainer: {
        flexDirection: 'row',
    },
    loginImage: {
        height: 50,
        width: 50,
        margin: 10,
    },
})