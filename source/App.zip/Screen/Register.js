import { StyleSheet, Text, View, TextInput, TouchableOpacity, Alert, Image } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { auth } from '../Firebase';

const Title = props => {

  return (
    <View style={styles.stylecontainer}>
      <Image style={styles.styleimage} source={props.pic}></Image>
      <Text style={props.styletitle}>{props.name}</Text>
    </View>
  );
};
const Button = props => {
  return (
    <TouchableOpacity style={styles.button} onPress={() =>
      this.props.navigation.navigate('Login')}>
      <Text style={styles.buttontext}>
        {props.title}
      </Text>

    </TouchableOpacity>
  );
}
const InputCell = props => {
  return (
    <View style={styles.InputCell}>
      <Icon name={props.icon} size={30} />
      <TextInput
        style={styles.input}
        value={props.inputvalue}
        placeholder={props.placeholder}
        onChangeText={props.inputtext}
      />
    </View>
  );
}





export default function Register({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <Title
        name="Create New Account"
        pic={require('../assets/react_native.png')}
        styletitle={styles.title}
      />
      <InputCell
        icon="account"
        placeholder="Enter username"
      />
      <InputCell
        // inputvalue="email"
        icon="email"
        placeholder="Email"
      />
      <InputCell
        icon="lock"
        placeholder="Enter password"
      />
      <InputCell
        icon="lock"
        placeholder="Confirm password"
      />
      <Button
        title="Create"
      />


      <View style={styles.movecontainer}>
        <Text style={styles.movecontent}>

          Already have an account?&nbsp;
        </Text>
        <TouchableOpacity onPress={() => navigation.navigate('login')}>
          <Text style={styles.move}>
            Login now!
          </Text>
        </TouchableOpacity>
      </View>




    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
    padding: 30,

  },
  stylecontainer: {

    alignItems: 'center',
  },
  styleimage: {
    margin: 10,

  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',


  },
  styleimage: {
    //justifyContent: 'center',
    //alignItems: 'center',
    width: 100,
    height: 100,
    paddingTop: 20,
    borderRadius: 50,
  },
  InputCell: {
    flexDirection: "row",
    borderColor: 'black',
    //border: '1px solid',
    height: 40,
    alignItems: 'center',
    paddingLeft: 10,
    width: '100%',
    borderRadius: 5,
    marginTop: 10,
    borderWidth: 1

  },
  forgotpass: {
    alignItems: "flex-end",
    marginTop: 5,
    color: '#f538b6',
  },
  input: {
    // borderWidth: 1, 
    borderColor: 'gray',
    width: '100%',
    paddingLeft: 10,
    height: "100%"
  },
  button: {
    backgroundColor: '#f5710c',
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    borderRadius: 5,
    marginVertical: 20
  },
  buttontext: {
    fontSize: 20,
    color: 'white',

  },
  another: {
    fontSize: 25,
    alignItems: 'center',
    fontWeight: 'bold',
  },
  movecontainer: {
    flexDirection: "row",
    justifyContent: 'center',
    marginVertical: 10,
  },
  move: {
    color: 'blue',
    fontWeight: 'bold',
  }
});
