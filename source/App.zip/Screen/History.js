import { StyleSheet, View, Text, FlatList } from 'react-native'
import React, { useEffect, useState, useContext } from 'react'
import Color from '../Color';
import { Calendar } from 'react-native-calendars';
import { AuthContext } from '../AuthContext';
import { FIREBASE_DB } from '../Firebase';
import { ref, onValue } from "firebase/database";
const CheckIn = () => {
    const [hist, setHist] = useState({});
    const [histDetails, setHistDetails] = useState({});
    const { uid } = useContext(AuthContext);
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'users/' + uid + '/hist'), (snapshot) => {
            const data = snapshot.val();
            setHist(data);
        })
    }, [FIREBASE_DB])
    useEffect(() => {
        return onValue(ref(FIREBASE_DB, 'users/' + uid + '/histDetails'), (snapshot) => {
            const data = snapshot.val();
            if (data) {
                setHistDetails(data);
            }
        })
    }, [FIREBASE_DB])
    return (
        <View style={styles.calendarContainer}>
            <Calendar
                style={styles.calendar}
                markedDates={hist}
                com />
            <View style={{ backgroundColor: '#fff', height: '33%', marginHorizontal: 10, borderRadius: 10, }}>
                <Text style={styles.header}>Chi tiết</Text>
                {histDetails
                    ? <FlatList
                        data={histDetails}
                        keyExtractor={item => item.date}
                        renderItem={({ item }) => (
                            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{ fontSize: 18, }}>
                                    Bạn đã tập vào ngày {item.date} lúc {item.time}
                                </Text>
                            </View>
                        )}
                    />
                    : <View style={{ justifyContent: 'center', alignItems: 'center', paddingVertical: 50, }}>
                        <Text style={{ fontSize: 17 }}>
                            Bạn chưa tập buổi nào
                        </Text>
                    </View>}
            </View>
        </View >
    )
}

export default CheckIn

const styles = StyleSheet.create({
    calendarContainer: {
    },
    calendar: {
        borderRadius: 10,
        marginHorizontal: 10,
        marginVertical: 10,
    },
    header: {
        paddingLeft: 10,
        paddingTop: 5,
        margin: 5,
        color: Color.button,
        fontWeight: 'bold',
        fontSize: 18,
    },
})