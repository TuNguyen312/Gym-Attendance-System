import React, { useContext } from 'react';
import { StyleSheet, StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Main from './Screen/Main';
import AuthStack from './Screen/AuthStack';
import { AuthContext, AuthProvider } from './AuthContext';

const Stack = createStackNavigator();

function AppNavigator() {
  const { isAuthenticated } = useContext(AuthContext);
  return (
    <NavigationContainer style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <Stack.Navigator>
        {isAuthenticated
          ? (<Stack.Screen name="Main" component={Main} options={{ headerShown: false }} />)
          : (<Stack.Screen name="AuthStack" component={AuthStack} options={{ headerShown: false }} />)
        }
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default function App() {
  return (
    <AuthProvider>
      <AppNavigator />
    </AuthProvider>
  );
}

